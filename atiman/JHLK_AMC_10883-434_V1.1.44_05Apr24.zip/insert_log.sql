insert into penta_version (n_fix_imp_no,module_id,version_no,version_dt,applied_dt,env_id) values (10883-434,'BPG_ANNUITY','JHLK_AMC_10883-434',to_date('05-APR-2024','DD-MON-YYYY'),SYSTIMESTAMP ,(select user||'@'||name from dual, v$database));
COMMIT;
/
